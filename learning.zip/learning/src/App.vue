<script>
  export default {
    data: () => ({
      contador: 10,
    }),  
    methods: {
      incrementar(){
        this.contador++;
      },
      disminuir(){
        this.contador--;
      },
      reset(){
        this.contador = 0;
        
      }
    }
  };
</script>


<template>
  <div class="container">
    <img src="./assets/logo.svg" alt="logo vue" width="125">
    <h1>Hola mundo Josue Peña</h1>
    <hr />
    <h2>contador {{contador}}</h2>
    <button @click="incrementar()">+1</button>
    <button @click="disminuir()">-1</button>
    <button @click="reset()">reset</button>
  </div>
</template>

<style scoped>
  .container{
    text-align: center;
  }
  h1{
    color: black;
    font-family: 'Roboto', sans-serif;
    font-weight: 300;
  }
  h2{
    font: bolder;
    font-family: 'Roboto', sans-serif;
    font-weight: 300;
    font-size: 2rem;
  }
  button{
    padding: 10px 20px;
    cursor: pointer;
    font-size: 1.5rem;
    margin:0 5px;
  }
</style>